package com.lepeman.pharmadatecheck.ui.canje

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.lepeman.pharmadatecheck.ui.viewmodels.CanjeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CampoBusquedaFormulario(
    consulta: String,
    sugerencias: List<String>,
    expanded: Boolean,
    onQueryChange: (String) -> Unit,
    onOptionSelected: (String) -> Unit,
    onExpandedChange: (Boolean) -> Unit,
    label: String = "Buscar...",
    modifier: Modifier = Modifier
) {
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { onExpandedChange(it) },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = consulta,
            onValueChange = {
                onQueryChange(it)
                if (it.isNotEmpty()) onExpandedChange(true)
            },
            label = { Text(label) },
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor(),
            singleLine = true
        )

        if (expanded && sugerencias.isNotEmpty()) {
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { onExpandedChange(false) }
            ) {
                sugerencias.forEach { opcion ->
                    DropdownMenuItem(
                        text = { Text(opcion) },
                        onClick = {
                            onOptionSelected(opcion)
                            onExpandedChange(false)
                        }
                    )
                }
            }
        }
    }
}